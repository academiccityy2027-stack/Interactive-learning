# Learning Universe — Academic City Schools, International Section

This upgrades the supplied school HTML. It preserves the embedded school logo, interactive subject planets, space entrance, dark/light themes, games, classroom tools and achievements. Shared accounts and assessed progress now use a Cloudflare Worker and a D1 database.

## Open the school application

Private owner preview: https://acis-learning-universe-school-app.peppybell32.chatgpt.site

The current hosted preview is private to the owner through the hosting platform. The school's username/password accounts are a separate layer. Enable the intended school audience in the site's sharing settings before inviting students. The school login itself requires no Gmail or student email. Do not upload this HTML alone to GitHub Pages: account, assessment and report features require the included server.

1. Register your school account using a username, a password of at least 10 characters, and a grade from 4 to 12. Save the recovery code privately.
2. Open your profile, choose **School administrator activation**, and use the private setup code supplied separately in this conversation. The code is not included in source files or frontend code. Initial administrator activation is allowed only once.
3. Have teachers register ordinary accounts. Open **Administrator** and grant teacher access to the correct accounts. Students cannot grant themselves teacher access.
4. Teachers choose a grade, open **Teacher dashboard**, create a class, and share its join code with the class. Students register with the matching grade and use **Join a class**.
5. Add resources, quizzes, videos or weekly missions. Choose a grade, subject, class, level and deadline. Add questions using the visual question editor. Each question has 2–6 choices, a correct choice number, topic and optional explanation.
6. Use a specific video URL, not a video search page. Videos must include at least one follow-up question. No credit is awarded for simply opening or marking a video.
7. Review completion, results and practice topics in the dashboard. Download **Export Excel** for a real .xlsx workbook, or **Export CSV** for spreadsheet import.
8. Students submit Arduino, robotics, coding and design projects to their class. Teachers approve them before class members see them. Galleries are scoped to authorized classes.

Existing browser-only accounts are not migrated: register a new shared account. Accounts from this version work across devices through the hosted database. Local storage remains only for device preferences and classroom convenience tools, not passwords, accounts or assessed progress.

## How scores and recommendations work

- Answers are marked on the server. Client-supplied scores are ignored.
- Results retain each assessed attempt and answer feedback.
- Completion means at least 60% on a task.
- XP uses the best score for each task: 10 XP per correct answer, plus 20 XP for a perfect score. Repeat attempts do not duplicate XP.
- Most active means the greatest number of distinct tasks completed in a class.
- Highest performance means the highest mean best-score percentage, with at least three assessed tasks. Awards use class-authorized data, not logins.
- Grade/subject recommendations use recent assessed answers: below 60% recommends foundation; 60–84% recommends core; 85%+ recommends stretch. This is a transparent rule-based pathway, not an AI diagnosis.
- Original subject challenges remain as clearly labelled foundation checks. Grade-band ICT missions and STEM stretch questions are included. Teachers should add the specific assessments for their curriculum and weekly lessons.
- Classroom games remain available for practice. Their browser-entered game scores do not count as assessed school performance.

## Virtual labs and provider icons

Free PhET activities include circuit construction, states of matter and pH. Concord's Next-Generation Molecular Workbench provides browser-based molecular experiments.

Official sources: https://phet.colorado.edu/ and https://mw.concord.org/nextgen/

External resource, platform and game cards use the official provider domain's favicon as their brand icon, including Wayground. These are real site icons rather than invented logos. A text fallback appears if a provider blocks or does not offer its favicon. Provider icons depend on external availability; the original school logo is embedded in the HTML.

Videos and the project gallery start empty until teachers/students add real content. No invented student projects or fictitious scores are included.

## Project files

- `public/index.html`: upgraded frontend (also supplied separately).
- `original.html`: retained user-supplied source used by the generator.
- `app.js`, `app.css`, `app.html`: application additions.
- `worker/api.js`: server routes, validation, access checks and spreadsheet export.
- `worker/seeds.json`: generated grade-tagged directory and starting assessments.
- `worker/index.js`: complete deployable Worker with embedded frontend and seed data.
- `drizzle/0000_school.sql`: database schema migration.
- `scripts/upgrade.py`: regenerate the application from the original HTML and additions.
- `scripts/build.sh`: generate and package the worker artifact.
- `tests/integration.mjs`: backend integration checks with Node's in-memory SQLite.

To change the app, edit the source additions or backend, then run `bash scripts/build.sh`. Requires Python 3 and Node. To check the backend, run `node tests/integration.mjs` using Node 24. An Excel test output is written to `/tmp/learning-universe-test-report.xlsx`.

## Independent Cloudflare deployment

Use the included `wrangler.jsonc` as a standalone starting point. Create a Cloudflare D1 database, replace its placeholder database ID with the ID returned by Cloudflare, apply `drizzle/0000_school.sql` to that database, set `ADMIN_SETUP_CODE` as a runtime secret, and deploy `worker/index.js` with Wrangler. The current private setup code is intentionally absent from the package; generate a fresh high-entropy code for an independent deployment. Use HTTPS; cookies are Secure, HttpOnly and SameSite=Strict.

The `.openai` manifest belongs to the hosted preview and should not be used to create an unrelated Site. Do not put passwords, activation codes, API keys or other secrets in frontend source or the hosting manifest. Back up the database using the hosting provider's database tooling.

## Verification

Integration checks passed for username registration, admin-only teacher approval, class isolation, reassigned class access, server marking, XP deduplication, recovery-code rotation, session revocation, project approval, CSRF checks and workbook generation. The .xlsx export was also opened with openpyxl. Hosted deployment succeeded and the production database contains the expected tables. Browser visual QA was unavailable in this session; layout and browser interactions were not visually inspected.
