from pathlib import Path
import json,subprocess,re
root=Path(__file__).resolve().parent.parent
s=(root/'original.html').read_text()
data=s[s.index('const D=')+8:s.index('\nconst AC=')].rstrip().rstrip(';')
(root/'extract.cjs').write_text('const d='+data+';process.stdout.write(JSON.stringify(d));')
D=json.loads(subprocess.check_output(['node',str(root/'extract.cjs')]))
(root/'extract.cjs').unlink()
seeds=[]
ranges={'Math Playground':(4,6),'Desmos':(7,12),'GeoGebra':(6,12),'Scratch':(4,8),'Blockly Games':(4,7),'NASA Space Place':(4,7),'National Geographic Kids':(4,7),'Ptable':(7,12),'MolView':(8,12),'ChemCollective':(9,12),'Tinkercad':(5,12),'Arduino':(8,12),'MakeCode micro:bit':(4,9)}
for sub in D:
 for i,l in enumerate(sub['l']):
  lo,hi=ranges.get(l[0],(4,12))
  for g in range(lo,hi+1):
   seeds.append(dict(id=f'resource-{sub["id"]}-{i}-{g}',owner_id='system',class_id=None,grade=g,subject=sub['id'],kind='resource',title=l[0],description=l[2],url=l[1],difficulty='foundation' if g<=6 else 'core',deadline=None,questions='[]'))
 # Preserve the original question bank as introductory practice, with explicit level.
 for g in range(4,13):
  qs=[dict(text=q[0],options=q[1],correct=q[2],topic=sub['en'],explanation='Review '+sub['en']+' and try the next activity.') for q in sub['q']]
  seeds.append(dict(id=f'quiz-{sub["id"]}-{g}',owner_id='system',class_id=None,grade=g,subject=sub['id'],kind='quiz',title=sub['en']+' · Foundation check',description='An introductory check from the original Learning Universe. Teachers can assign deeper grade-specific quizzes.',url='',difficulty='foundation',deadline=None,questions=json.dumps(qs)))
# Grade-specific ICT and STEM pathways, with assessed foundations/core/stretch.
for g in range(4,13):
 if g<=6:
  qs=[('Which block repeats an instruction?', ['Loop','Paint','Sound off'],0,'Loops'),('What does a robot sensor do?',['Detects its surroundings','Only decorates the robot','Writes a story'],0,'Sensors'),('An algorithm is…',['A sequence of steps','A battery','A picture only'],0,'Algorithms')]
  title='Robot explorer: inputs and instructions'; level='core'
 elif g<=9:
  qs=[('Which HTML tag creates a hyperlink?',['<a>','<p>','<h1>'],0,'HTML'),('Which is a robot input?',['Distance sensor','Motor','LED'],0,'Inputs and outputs'),('If distance < 10, stop the motor. This uses…',['A condition','Only a variable name','An HTML heading'],0,'Conditions')]
  title='Code navigator: HTML and robotics';level='core'
 else:
  qs=[('What does Python print?\nprint(sum(range(1, 5)))',['10','15','5'],0,'Python loops'),('Which Arduino call reads an analogue sensor?',['analogRead(A0)','digitalWrite(13, HIGH)','pinMode(13, OUTPUT)'],0,'Arduino inputs'),('Why test an input at its threshold value?',['To check boundary behaviour','To avoid all testing','To change the board colour'],0,'Testing')]
  title='Engineering pilot: Python and Arduino';level='core'
 seeds.append(dict(id=f'ict-path-{g}',owner_id='system',class_id=None,grade=g,subject='ict',kind='mission',title=title,description='Complete the assessment, then build or simulate a small project and document three tests.',url='https://www.tinkercad.com/circuits',difficulty=level,deadline=None,questions=json.dumps([dict(text=t,options=o,correct=c,topic=p,explanation='Use the topic resource to revise this concept.') for t,o,c,p in qs])))
 stretch=[dict(text='A light switches on at a reading below 300. Which test checks the boundary?',options=['299, 300 and 301','Only 0','Only 1000'],correct=0,topic='Boundary tests',explanation='Check just below, at and just above the threshold.'),dict(text='A motor never stops when the sensor disconnects. What should you add?',options=['A safe fallback for invalid readings','A brighter LED','A longer project name'],correct=0,topic='Safe control',explanation='Detect invalid sensor readings and put outputs into a safe state.')]
 seeds.append(dict(id=f'ict-stretch-{g}',owner_id='system',class_id=None,grade=g,subject='ict',kind='quiz',title='STEM stretch · reliable systems',description='Explore test cases and reliable control after your core challenge.',url='',difficulty='stretch',deadline=None,questions=json.dumps(stretch)))
labs=[('PhET · Circuit Construction Kit','https://phet.colorado.edu/en/simulations/circuit-construction-kit-dc','Build a circuit, change voltage and observe current.',4,12,'physics'),('PhET · States of Matter','https://phet.colorado.edu/en/simulations/states-of-matter-basics','Change temperature and compare solids, liquids and gases.',4,9,'science'),('PhET · pH Scale','https://phet.colorado.edu/en/simulations/ph-scale-basics','Compare acids and bases safely in a virtual experiment.',7,12,'chemistry'),('Concord · Molecular Workbench','https://mw.concord.org/nextgen/','Browser-based molecular models and interactive experiments.',7,12,'science')]
for i,(title,u,d,lo,hi,sj) in enumerate(labs):
 for g in range(lo,hi+1):seeds.append(dict(id=f'lab-{i}-{g}',owner_id='system',class_id=None,grade=g,subject=sj,kind='resource',title=title,description='Free virtual lab · '+d,url=u,difficulty='foundation' if g<=6 else 'core',deadline=None,questions='[]'))
(root/'worker/seeds.json').write_text(json.dumps(seeds,ensure_ascii=False))
# Remove answer keys from the browser while preserving the original subject directory.
for sub in D: sub.pop('q',None)
a=s.index('const D=');b=s.index('\nconst AC=',a)
s=s[:a]+'const D='+json.dumps(D,ensure_ascii=False)+';'+s[b:]
# Remove browser-only accounts/progress and stop trusting frontend XP.
a=s.index('const US=');b=s.index('const T=',a)
s=s[:a]+"let CU='guest';let P={xp:0,streak:0,best:0,sc:{},tm:['Team 1','Team 2','Team 3','Team 4'].map(n=>({n,p:0}))};const sv=()=>{};\n"+s[b:]
s=re.sub(r'function addXP\(n\)\{[^\n]+\}', 'function addXP(n){}',s)
a=s.index('function openSub(');b=s.index('const dm=',a)
s=s[:a]+"function openSub(id,tab){closePal();showSubject(id,tab)}\n"+s[b:]
a=s.index('// Videos');b=s.index('// Hero:',a)
s=s[:a]+"function vrender(){if(typeof renderLearning==='function')renderLearning()}\n"+s[b:]
a=s.index('// Accounts and entrance');b=s.index('// Theme + dock',a)
s=s[:a]+(root/'app.js').read_text()+"\n"+s[b:]
s=s.replace("$('rst').onclick=()=>{if(confirm('Reset all XP and progress on this device?')){P={xp:0,streak:0,best:0,sc:{},tm:P.tm};sv();hud();vrender();toast('Progress reset')}};","$('rst').hidden=true;")
s=s.replace('Progress is saved only on this device.','Signed-in profiles and assessed progress sync across devices.')
s=s.replace('Tap a planet to unlock free websites (most need no sign-in) and a quick challenge. Earn XP, build streaks and master all ten worlds.','Tap a planet to explore resources for your grade. Complete assessed missions, collect badges and launch your next project.')
s=s.replace("['⚡','Math Whiz','Score 10+ in Math Sprint',()=>(P.sprint||0)>=10],['🔤','Word Wizard','Solve 5 word scrambles',()=>(P.words||0)>=5],",'')
s=s.replace('Mark 3 videos as watched','Pass 3 video follow-up checks').replace("Object.keys(P.vw||{}).length>=3","(APP.videoPassed||0)>=3")
s=re.sub(r'<section class="sec" id="videos">.*?</section>', '<section class="sec" id="videos"><div class="row"><h2>🎬 Teacher-selected videos</h2><span class="pill">Watch → answer → learn</span></div><p class="mut">Specific videos selected by your teachers, with a follow-up assessment. Opening a video earns no XP.</p><div class="links" id="videoCards"></div></section>',s,flags=re.S)
# Search is restricted to resources loaded for the selected grade.
a=s.index('let hits=[];function rs()');b=s.index('function openPal()',a)
s=s[:a]+"let hits=[];function rs(){const q=$('pq').value.trim().toLowerCase();hits=APP.content.filter(c=>(c.title+' '+c.description).toLowerCase().includes(q)).slice(0,10).map(c=>[c.title,'Grade '+c.grade+' · '+c.kind,()=>c.questions.length?assess(c):window.open(c.url,'_blank','noopener,noreferrer')]);$('pr').replaceChildren(...hits.map(h=>{const b=el('button');b.append(el('span',null,h[0]),el('span','mut',h[1]));b.onclick=()=>{closePal();h[2]()};return b}))}\n"+s[b:]
s=s.replace('</style>',(root/'app.css').read_text()+'\n</style>',1)
s=s.replace('<main>','<main>'+(root/'app.html').read_text(),1)
s=s.replace('<html lang="en">','<html lang="en" data-theme="dark">')
s=s.replace('Academic City Schools - International','Academic City Schools — International Section')
# Practice games stay available, while points used for reports only come from server marking.
s=s.replace('+8 XP','· practice').replace('+5 XP','· practice').replace('+10 XP','· practice').replace('+20 XP','· practice')
# Keep logos on every external content card, including existing hubs/platforms.
s=s.replace("hud();\n})();","hud();\nlogoCards(document);new MutationObserver(ms=>ms.forEach(m=>m.addedNodes.forEach(n=>{if(n.nodeType===1)logoCards(n)}))).observe(document.body,{childList:true,subtree:true});\n})();")
(root/'public/index.html').write_text(s)
# Embed essential bytes for Worker ESM delivery; keep editable source files in the package.
api=(root/'worker/api.js').read_text().replace('export async function api','async function api')
(root/'worker/index.js').write_text('const HTML='+json.dumps(s,ensure_ascii=False)+';\nconst SEEDS='+json.dumps(seeds,ensure_ascii=False)+';\n'+api+'\nexport default {async fetch(req,env){const u=new URL(req.url);let r;if(u.pathname.startsWith("/api/"))r=await api(req,env,SEEDS);else if(u.pathname==="/"||u.pathname==="/index.html")r=new Response(HTML,{headers:{"Content-Type":"text/html; charset=utf-8","Cache-Control":"no-cache"}});else r=new Response("Not found",{status:404});const h=new Headers(r.headers);h.set("X-Content-Type-Options","nosniff");h.set("Referrer-Policy","no-referrer");h.set("Permissions-Policy","camera=(),microphone=(),geolocation=()");h.set("Content-Security-Policy","default-src \'self\'; script-src \'self\' \'unsafe-inline\'; style-src \'self\' \'unsafe-inline\'; img-src \'self\' data: blob: https:; connect-src \'self\'; frame-ancestors \'self\' https://chatgpt.com; base-uri \'self\'; form-action \'self\'");return new Response(r.body,{status:r.status,headers:h});}};\n')
